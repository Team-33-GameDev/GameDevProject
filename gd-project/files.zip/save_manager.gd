extends Node

# Путь к файлу сохранения. user:// — это безопасная папка пользователя
# (на Windows: %APPDATA%/Godot/app_userdata/GDProject/)
const SAVE_PATH: String = "user://savegame.json"

# Версия формата сохранения — пригодится, если структура поменяется в будущем
const SAVE_VERSION: int = 1


func _ready() -> void:
	# Сохраняемся автоматически, когда игрок закрывает окно (крестик, Alt+F4 и т.п.)
	get_tree().set_auto_accept_quit(false)


func _notification(what: int) -> void:
	# Перехватываем закрытие окна, чтобы успеть сохраниться
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		save_game()
		get_tree().quit()


# Есть ли вообще сохранение на диске
func has_save() -> bool:
	return FileAccess.file_exists(SAVE_PATH)


# Собираем текущее состояние игры в словарь и пишем в файл
func save_game() -> void:
	var data: Dictionary = {
		"version": SAVE_VERSION,
		"score": GameManager.score,
		"tickets": GameManager.tickets,
		"current_quota_index": QuotaManager.current_quota_index,
		"time_left": QuotaManager.time_left,
		"current_quota_target": QuotaManager.current_quota_target,
		"current_state": int(QuotaManager.current_state),
	}

	var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file == null:
		push_error("SaveManager: не удалось открыть файл для записи: %s" % FileAccess.get_open_error())
		return

	file.store_string(JSON.stringify(data, "\t"))
	file.close()
	print("💾 SaveManager: игра сохранена.")


# Читаем файл и возвращаем словарь (или пустой словарь, если что-то не так)
func load_game() -> Dictionary:
	if not has_save():
		return {}

	var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if file == null:
		push_error("SaveManager: не удалось открыть файл для чтения.")
		return {}

	var text := file.get_as_text()
	file.close()

	var parsed: Variant = JSON.parse_string(text)
	if typeof(parsed) != TYPE_DICTIONARY:
		push_error("SaveManager: файл сохранения повреждён.")
		return {}

	return parsed


# Применяем загруженные данные к менеджерам.
# Вызывается, когда игрок продолжает игру.
func apply_save() -> bool:
	var data := load_game()
	if data.is_empty():
		return false

	# .get() с дефолтом — защита от старых/битых сохранений без какого-то поля
	GameManager.tickets = int(data.get("tickets", 0))
	GameManager.score = int(data.get("score", 0))

	QuotaManager.current_quota_index = int(data.get("current_quota_index", 0))
	QuotaManager.time_left = float(data.get("time_left", 0.0))
	QuotaManager.current_quota_target = int(data.get("current_quota_target", 0))
	QuotaManager.current_state = data.get("current_state", QuotaManager.GameState.IDLE) as QuotaManager.GameState

	print("📂 SaveManager: сохранение загружено.")
	return true


# Удаляем файл сохранения (вызывается при смерти — прогресс сбрасывается)
func delete_save() -> void:
	if has_save():
		DirAccess.remove_absolute(SAVE_PATH)
		print("🗑️ SaveManager: сохранение удалено (смерть).")
