extends Control

func _ready():
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _on_play_button_pressed():
	# Если есть сохранение — продолжаем с того места, где закрыли игру.
	# Если нет — начинаем новую игру (менеджеры уже в дефолтном состоянии).
	if SaveManager.has_save():
		SaveManager.apply_save()
	get_tree().change_scene_to_file("res://scenes/levels/game_room.tscn")

func _on_settings_pressed():
	get_tree().change_scene_to_file("res://scenes/ui/settings.tscn")

func _on_quit_pressed():
	# Сохраняемся перед выходом из меню тоже (на случай, если игрок выходит отсюда)
	SaveManager.save_game()
	get_tree().quit()
